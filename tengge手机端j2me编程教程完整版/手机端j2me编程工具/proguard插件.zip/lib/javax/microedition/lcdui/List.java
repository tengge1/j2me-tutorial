// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   List.java

package javax.microedition.lcdui;


// Referenced classes of package javax.microedition.lcdui:
//			Screen, Image, ChoiceGroup, Form, 
//			Command, Choice, Display, CommandListener, 
//			Ticker, Font, Graphics, Item

public class List extends Screen
	implements Choice
{

	public static final Command SELECT_COMMAND = new Command("", 1, 0);
	private Form form;
	private ChoiceGroup cg;
	private Command selectCommand;
	private int listType;

	public List(String title, int listType)
	{
		this(title, listType, new String[0], new Image[0]);
	}

	public List(String title, int listType, String stringElements[], Image imageElements[])
	{
		super(title);
		selectCommand = SELECT_COMMAND;
		this.listType = listType;
		if (listType != 3 && listType != 1 && listType != 2)
			throw new IllegalArgumentException();
		synchronized (Display.LCDUILock)
		{
			cg = new ChoiceGroup(null, listType, stringElements, imageElements, true);
			cg.isList = true;
			form = new Form(title);
			form.paintDelegate = this;
			form.append(cg);
		}
	}

	public void setTicker(Ticker ticker)
	{
		form.setTicker(ticker);
	}

	public Ticker getTicker()
	{
		return form.getTicker();
	}

	public void setTitle(String s)
	{
		super.setTitle(s);
		form.setTitle(s);
	}

	public int size()
	{
		return cg.size();
	}

	public String getString(int elementNum)
	{
		return cg.getString(elementNum);
	}

	public Image getImage(int elementNum)
	{
		return cg.getImage(elementNum);
	}

	public int append(String stringPart, Image imagePart)
	{
		return cg.append(stringPart, imagePart);
	}

	public void insert(int elementNum, String stringPart, Image imagePart)
	{
		cg.insert(elementNum, stringPart, imagePart);
	}

	public void delete(int elementNum)
	{
		cg.delete(elementNum);
	}

	public void deleteAll()
	{
		cg.deleteAll();
	}

	public void set(int elementNum, String stringPart, Image imagePart)
	{
		cg.set(elementNum, stringPart, imagePart);
	}

	public boolean isSelected(int elementNum)
	{
		return cg.isSelected(elementNum);
	}

	public int getSelectedIndex()
	{
		return cg.getSelectedIndex();
	}

	public int getSelectedFlags(boolean selectedArray_return[])
	{
		return cg.getSelectedFlags(selectedArray_return);
	}

	public void setSelectedIndex(int elementNum, boolean selected)
	{
		cg.setSelectedIndex(elementNum, selected);
	}

	public void setSelectedFlags(boolean selectedArray[])
	{
		cg.setSelectedFlags(selectedArray);
	}

	public void removeCommand(Command cmd)
	{
		synchronized (Display.LCDUILock)
		{
			super.removeCommandImpl(cmd);
			if (cmd == selectCommand)
				selectCommand = null;
		}
	}

	public void setSelectCommand(Command command)
	{
		if (cg.getType() != 3)
			return;
		if (command == SELECT_COMMAND)
		{
			selectCommand = command;
			return;
		}
		if (command == null)
		{
			selectCommand = null;
			return;
		}
		synchronized (Display.LCDUILock)
		{
			addCommandImpl(command);
			selectCommand = command;
		}
	}

	public void setFitPolicy(int fitPolicy)
	{
		cg.setFitPolicy(fitPolicy);
	}

	public int getFitPolicy()
	{
		return cg.getFitPolicy();
	}

	public void setFont(int elementNum, Font font)
	{
		cg.setFont(elementNum, font);
	}

	public Font getFont(int elementNum)
	{
		return cg.getFont(elementNum);
	}

	void callShowNotify(Display d)
	{
		super.callShowNotify(d);
		form.callShowNotify(d);
	}

	void callHideNotify(Display d)
	{
		super.callHideNotify(d);
		form.callHideNotify(d);
	}

	void callKeyPressed(int keyCode)
	{
		form.callKeyPressed(keyCode);
		if (keyCode == Display.KEYCODE_SELECT)
		{
			if (cg.size() == 0)
				return;
			CommandListener cl = null;
			synchronized (Display.LCDUILock)
			{
				cl = listener;
			}
			if (cl != null && listType == 3)
				try
				{
					synchronized (Display.calloutLock)
					{
						cl.commandAction(selectCommand, this);
					}
				}
				catch (Throwable thr)
				{
					Display.handleThrowable(thr);
				}
		}
	}

	void callPaint(Graphics g, Object target)
	{
		form.callPaint(g, target);
	}

	void callInvalidate(Item src)
	{
		form.callInvalidate(src);
	}

	void callItemStateChanged(Item src)
	{
		form.callItemStateChanged(src);
	}

}
