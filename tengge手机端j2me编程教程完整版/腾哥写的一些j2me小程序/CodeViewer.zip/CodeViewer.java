import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Midlet extends MIDlet implements CommandListener
{
    Display display;
    Form form;
    TextField textfield;
    Command view,about,exit;
    Alert alert;
    
    public Midlet()
    {
        display=Display.getDisplay(this);
        form=new Form("汉字编码");
        alert=new Alert("作者","李腾",null,AlertType.INFO);
        alert.setTimeout(5000);
        textfield=new TextField("输入文字","",5,TextField.ANY);
        view=new Command("查看",Command.ITEM,2);
        about=new Command("关于",Command.ITEM,2);
        exit=new Command("退出",Command.EXIT,2);
        form.append(textfield);
        form.addCommand(view);
        form.addCommand(about);
        form.addCommand(exit);
        form.setCommandListener(this);
        }
        
    public void startApp()
    {
        display.setCurrent(form);
        }
    
    public void commandAction(Command c,Displayable d)
    {
        if(c==view) view();
        if(c==about) about();
        if(c==exit) notifyDestroyed();
        }
        
    public void view()
    {
        String string=textfield.getString();
        form.deleteAll();
        form.append(textfield);
        String []encoding={"utf-8","utf-7","utf-16","gbk","gb2312","big5"};
        for(int i=0;i<encoding.length;i++)
            form.append(encoding[i]+":"+encode(string,encoding[i])+"\n");
        }
    
    public void about()
    {
        display.setCurrent(alert);
        }
    
    public String encode(String string,String enc)
    {
        try
        {
            byte []bytes=string.getBytes(enc);
            String hex="0123456789abcdef";
            StringBuffer buffer=new StringBuffer();
            for(int i=0;i<bytes.length;i++)
            {
                buffer.append(hex.charAt((bytes[i]>>4)&15));
                buffer.append(hex.charAt(bytes[i]&15));
                }
            return(buffer.toString());
            }
        catch(Exception e)
        {
            return(null);
            }
        }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean arg0) {}
    }
