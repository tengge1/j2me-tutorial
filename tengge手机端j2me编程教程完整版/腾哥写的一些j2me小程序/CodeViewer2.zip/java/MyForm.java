import javax.microedition.lcdui.*;

public class MyForm extends Form implements CommandListener
{
    public static Midlet midlet;
    TextField textfield;
    Command view,back;
    
    public MyForm()
    {
        super("汉字编码");
        textfield=new TextField("输入文字","",5,TextField.ANY);
        view=new Command("查看",Command.ITEM,2);
        back=new Command("返回",Command.BACK,2);
        append(textfield);
        addCommand(view);
        addCommand(back);
        setCommandListener(this);
        }
            
    public void commandAction(Command c,Displayable d)
    {
        if(c==view) view();
        if(c==back) midlet.cmd("主菜单");
        }
        
    public void view()
    {
        String string=textfield.getString();
        deleteAll();
        append(textfield);
        String []encoding={"utf-8","utf-7","utf-16","gbk","gb2312","big5"};
        for(int i=0;i<encoding.length;i++)
            append(encoding[i]+":"+encode(string,encoding[i])+"\n");
        }
    
    public String encode(String string,String enc)
    {
        try
        {
            byte []bytes=string.getBytes(enc);
            String hex="0123456789abcdef";
            StringBuffer buffer=new StringBuffer();
            for(int i=0;i<bytes.length;i++)
            {
                buffer.append(hex.charAt((bytes[i]>>4)&15));
                buffer.append(hex.charAt(bytes[i]&15));
                }
            return(buffer.toString());
            }
        catch(Exception e)
        {
            return(null);
            }
        }
    }

