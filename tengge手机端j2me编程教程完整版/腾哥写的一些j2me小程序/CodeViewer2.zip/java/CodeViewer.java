import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Midlet extends MIDlet
{
    Display display;
    MyMenu menu;
    
    public Midlet()
    {
        display=Display.getDisplay(this);
        MyMenu.midlet=this;
        menu=new MyMenu();
        display.setCurrent(menu);
        MyForm.midlet=this;
        MyHelp.midlet=this;
        MyAbout.midlet=this;
        }
        
    public void startApp()
    {
        }
    
    
    public void cmd(String action)
    {
        if(action.equals("主菜单"))
        display.setCurrent(menu);
        if(action.equals("开始使用"))
        display.setCurrent(new MyForm());
        if(action.equals("使用帮助"))
        display.setCurrent(new MyHelp());
        if(action.equals("软件关于"))
        display.setCurrent(new MyAbout());
        if(action.equals("退出软件"))
        notifyDestroyed();
        }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean arg0) {}
    }
