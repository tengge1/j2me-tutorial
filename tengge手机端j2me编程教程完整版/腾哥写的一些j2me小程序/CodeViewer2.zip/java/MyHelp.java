import javax.microedition.lcdui.*;

public class MyHelp extends Canvas
{
    public static Midlet midlet;
    public MyHelp()
    {
        setFullScreenMode(true);
        }
         
    public void paint(Graphics g)
    {
        g.setColor(200,20,50);
        g.fillRect(0,0,getWidth(),getHeight());
        g.setColor(0,0,80);
        g.drawString("帮助：",getWidth()/2,20,Graphics.TOP|Graphics.HCENTER);       
        g.drawString("选择开始使用，输入",getWidth()/2,50,Graphics.TOP|Graphics.HCENTER);
        g.drawString("文字点击查看即可。",getWidth()/2,80,Graphics.TOP|Graphics.HCENTER);
        g.drawString("返回",getWidth(),getHeight(),Graphics.BOTTOM|Graphics.RIGHT);}

    public void pointerPressed(int x,int y)
    {
        if(x>getWidth()-40&x<getWidth()&y>getHeight()-30&y<getHeight())
            midlet.cmd("主菜单");
        }
    
    public void keyPressed(int keyCode)
    {
        if(keyCode==-7)
        {
            midlet.cmd("主菜单");
            }
        }
    }
