import javax.microedition.lcdui.*;

public class MyAbout extends Canvas
{
    public static Midlet midlet;
    public MyAbout()
    {
        setFullScreenMode(true);
        }
     
    public void paint(Graphics g)
    {
        g.setColor(200,20,50);
        g.fillRect(0,0,getWidth(),getHeight());
        g.setColor(0,0,80);
        g.drawString("游戏关于：",getWidth()/2,80,Graphics.TOP|Graphics.HCENTER);        
        g.drawString("作者：李腾",getWidth()/2,110,Graphics.TOP|Graphics.HCENTER);
        g.drawString("QQ:930372551",getWidth()/2,140,Graphics.TOP|Graphics.HCENTER);
        g.drawString("移动Mobile Market",getWidth()/2,170,Graphics.TOP|Graphics.HCENTER);
        g.drawString("返回",getWidth(),getHeight(),Graphics.BOTTOM|Graphics.RIGHT);}
    
    public void pointerPressed(int x,int y)
    {
        if(x>getWidth()-40&x<getWidth()&y>getHeight()-30&y<getHeight())
            midlet.cmd("主菜单");
        }
    
    public void keyPressed(int keyCode)
    {
        if(keyCode==-7)
        {
            midlet.cmd("主菜单");
            }
        }
    }
