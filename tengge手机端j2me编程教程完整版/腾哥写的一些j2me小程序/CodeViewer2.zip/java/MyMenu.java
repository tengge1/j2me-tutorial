import javax.microedition.lcdui.*;

public class MyMenu extends Canvas
{
    public static Midlet midlet;
    private int index;
    Image word,arrow;
    int width,height;
    
    public MyMenu()
    {
        setFullScreenMode(true);
        width=getWidth();
        height=getHeight();
        index=0;
        try
        {
            word=Image.createImage("/word.png");
            arrow=Image.createImage("/arrow.png");
            }
        catch(Exception e) {}
        }
    
    public void paint(Graphics g)
    {
        g.setColor(200,20,50);
        g.fillRect(0,0,getWidth(),getHeight());
        g.setColor(0,0,80);
        g.drawImage(word,width/2,height/2,Graphics.HCENTER|Graphics.VCENTER);
        g.drawImage(arrow,width/2-80,height/2-20+index*30,Graphics.HCENTER|Graphics.VCENTER);
        g.drawString("选择",0,height,Graphics.LEFT|Graphics.BOTTOM);
        }
    
    public void keyPressed(int keyCode)
    {
        switch(getGameAction(keyCode))
        {
            case UP:index-=1;break;
            case DOWN:index+=1;break;
            case FIRE:select();
            }
        if(index==4) index=0;
        if(index==-1) index=3;
        if(keyCode==-6) select();
        repaint();
        }
    
    public void select()
    {
        switch(index)
        {
            case 0:
            midlet.cmd("开始使用");break;
            case 1:
            midlet.cmd("使用帮助");break;
            case 2:
            midlet.cmd("软件关于");break;
            case 3:
            midlet.cmd("退出软件");break;
            }
        }
    
    public void pointerPressed(int x,int y)
    {
        if(x>width/2-55&&x<width/2+65&&y>height/2-37&&y<height/2-5)
        index=0;
        if(x>width/2-55&&x<width/2+65&&y>height/2-5&&y<height/2+25)
        index=1;
        if(x>width/2-55&&x<width/2+65&&y>height/2+25&&y<height/2+56)
        index=2;
        if(x>width/2-55&&x<width/2+65&&y>height/2+56&&y<height/2+89)
        index=3;
        if(x>0&&x<45&&y>height-30&&y<height)
        select();
        }
    }
