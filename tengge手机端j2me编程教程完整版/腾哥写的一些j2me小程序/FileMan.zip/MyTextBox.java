import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.io.file.*;
import java.io.*;

public class MyTextBox extends TextBox implements CommandListener
{
    static Midlet midlet;
    Command save,back;
    FileConnection fc;
    String enc;
    
    public MyTextBox(String url)
    {
        super("记事本","",2000,TextField.ANY);
        save=new Command("保存",Command.SCREEN,1);
        back=new Command("返回",Command.BACK,1);
        addCommand(save);
        addCommand(back);
        setCommandListener(this);
        try
        {
            fc=(FileConnection)Connector.open("file:///"+url);
            int size=(int)fc.fileSize();
            setMaxSize(size+100);
            byte []bytes=new byte[size];
            DataInputStream is=(DataInputStream)fc.openDataInputStream();
            is.readFully(bytes);
            is.close();
            fillBox(bytes);
            }
        catch(Exception e)
        {
            midlet.note(e.toString());
            }
        }
    
    public void fillBox(byte []bytes)
    {
        String encodings[]={"utf-8","gbk","utf-16","big5","utf-7"};
        for(int i=0;i<encodings.length;i++)
        {
            try
            {
                setString(new String(bytes,encodings[i]));
                enc=encodings[i];
                }
            catch(Exception e){}
            }
        }
    
    public void commandAction(Command c,Displayable d)
    {
        if(c==save)
        {
            save();
            midlet.note("保存成功！");
            }
        if(c==back)
        {
            try
            {
                fc.close();
                }
            catch(Exception e){}
            midlet.cmd("浏览器");}
        }
    
    public void save()
    {
        try
        {
            if(fc.exists())
            {
                fc.delete();
                fc.create();
                }
            DataOutputStream os=fc.openDataOutputStream();
            byte b[]=getString().getBytes(enc);
            os.write(b,0,b.length);
            os.close();
            }
        catch(Exception e)
        {midlet.note(e.toString());}
        }
    }
