import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.io.file.*;
import java.io.*;

public class MyImage extends Form implements CommandListener
{
    public static Midlet midlet;
    Command exit;
    
    public MyImage(String url)
    {
        super("图片查看器");
        exit=new Command("返回",Command.EXIT,1);
        addCommand(exit);
        setCommandListener(this);
        try
        {
            FileConnection fc=(FileConnection)Connector.open("file:///"+url);
            InputStream is=fc.openInputStream();
            Image image=Image.createImage(is);
            is.close();
            fc.close();
            ImageItem imageitem=new ImageItem("图片",image,Item.LAYOUT_CENTER,"无法显示");
            imageitem.setPreferredSize(150,-1);
            append(imageitem);
            }
        catch(Exception e)
        {
            midlet.note(e.toString());
            }
        }
    
    public void commandAction(Command c,Displayable d)
    {
        if(c==exit) midlet.cmd("浏览器");
        }
    }
