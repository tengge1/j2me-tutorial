import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.io.file.*;
import java.util.*;

public class FileMan extends List implements CommandListener
{
    //请设置全局变量
    static Midlet midlet;
    Command select,forward,backward,about,exit;
    Enumeration enum;
    String path;
    FileConnection fc;
    
    public FileMan()
    {
        //请填充构造方法
        super("浏览器",List.IMPLICIT);
        select=new Command("查看",Command.SCREEN,1);
        forward=new Command("进入",Command.SCREEN,1);
        backward=new Command("返回",Command.BACK,1);
        about=new Command("关于",Command.HELP,1);
        exit=new Command("退出",Command.EXIT,1);
        setSelectCommand(forward);
        addCommand(backward);
        addCommand(select);
        addCommand(about);
        addCommand(exit);
        setCommandListener(this);
        fillList();
        }
        
    public void commandAction(Command c,Displayable d)
    {
        if(c==select) view();
        if(c==forward) forward();
        if(c==backward) backward();
        if(c==about) midlet.note("作者：李腾");
        if(c==exit) midlet.cmd("退出");
        }
    
    public void view()
    {
        try{
        String tmpPath;
        if(path==null) tmpPath="";
        else tmpPath=path;
        int index=getSelectedIndex();
        FileConnection fc=connect(tmpPath+getString(index));
        StringBuffer sb;
        if(fc==null) return;
        else if(path==null)
        {
            sb.append("总大小："+fc.totalSize());
            sb.append("•空余大小："+fc.availableSize());
            sb.append("•使用大小："+fc.usedSize());
            sb.append("•路径："+fc.getPath());
            sb.append("•URL："+fc.getURL());}
        else if(fc.isDirectory())
        {
            sb.append("•目录大小："+fc.directorySize(true));
            if(fc.canRead())
            sb.append("•文件夹可读");
            else
            sb.append("•文件夹不可读");
            if(fc.canWrite())
            sb.append("•文件夹可写");
            else
            sb.append("•文件夹不可写");
            if(fc.isHidden())
            sb.append("•文件夹隐藏");
            else
            sb.append("•文件夹不隐藏");
            sb.append("•路径："+fc.getPath());
            sb.append("•URL："+fc.getURL());}
        else
        {
            sb.append("•文件大小："+fc.fileSize());
            if(fc.canRead())
            sb.append("•文件可读");
            else
            sb.append("•文件不可读");
            if(fc.canWrite())
            sb.append("•文件可写");
            else
            sb.append("•文件不可写");
            if(fc.isHidden())
            sb.append("•文件隐藏");
            else
            sb.append("•文件不隐藏");
            sb.append("•文件名："+fc.getName());
            sb.append("•路径："+fc.getPath());
            sb.append("•URL："+fc.getURL());
            sb.append("•最后修改："+fc.lastModified());            
            }
            close(fc);}
        catch(Exception e) {}
        }
    
    public void forward()
    {
        int index=getSelectedIndex();
        String string=getString(index);
        if(path==null) path=string;
        else path=path+string;
        FileConnection fc=connect(path);
        if(fc!=null)
        {
            if(fc.isDirectory())
            {
                fillList();
                }
            close(fc);
            }
        }
    
    public void backward()
    {
        if(path!=null)
        {
            int start=path.lastIndexOf(0x2f,path.length()-2);
            if(start!=-1)
            {
                String tmpPath=path.substring(0,start+1);
                FileConnection fc=connect(tmpPath);
                if(fc!=null)
                {
                    path=tmpPath;
                    fillList();
                    close(fc);
                    }
                }
            else
            {
                path=null;
                fillList();
                close(fc);
                }
            }
        }
    
    public FileConnection connect(String path)
    {
        try
        {
            FileConnection connection=(FileConnection)Connector.open("file:///"+path);
            return(connection);
            }
        catch(Exception e)
        {
            midlet.note(e.toString());
            return(null);
            }
        }
    
    public void close(FileConnection fc)
    {
        try
        {
            fc.close();
            }
        catch(Exception e) {}
        }
        
    private void fillList()
    {
        try{
        if(path==null)
        enum=FileSystemRegistry.listRoots();
        else
        enum=fc.list();}
        catch(Exception e)
        {}
        deleteAll();
        while(enum.hasMoreElements())
        {
            append((String)enum.nextElement(),null);
            }
        try{
            setSelectedIndex(0,true);}
        catch(Exception e) {}
        }    
    }
