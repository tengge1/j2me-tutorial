import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;

public class MyPlayer extends Form implements CommandListener
{
    public static Midlet midlet;
    Player player;
    Command play,stop,up,down,back;
    VolumeControl control;
    
    public MyPlayer(String url)
    {
        super("音乐播放器");
        play=new Command("播放",Command.ITEM,1);
        stop=new Command("暂停",Command.ITEM,1);
        up=new Command("增大音量",Command.ITEM,1);
        down=new Command("减小音量",Command.ITEM,1);
        back=new Command("返回",Command.BACK,1);
        addCommand(play);
        addCommand(stop);
        addCommand(up);
        addCommand(down);
        addCommand(back);
        setCommandListener(this);
        try
        {
            player=Manager.createPlayer("file:///"+url);
            player.realize();
            player.prefetch();
            control=(VolumeControl)player.getControl("VolumeControl");
            control.setLevel(30);
            }
        catch(Exception e)
        {
            midlet.note(e.toString());
            }
        }
    
    public void commandAction(Command c,Displayable d)
    {
        if(c==play) play();
        if(c==stop) stop();
        if(c==up) control.setLevel(Math.min(control.getLevel()+10,100));
        if(c==down) control.setLevel(Math.max(control.getLevel()-10,0));
        if(c==back)
        {
            stop();
            midlet.cmd("浏览器");
            }
        }
    
    public void play()
    {
        try{
        player.start();}
        catch(Exception e)
        {midlet.note(e.toString());}
        }
    
    public void stop()
    {
        try{
        player.stop();}
        catch(Exception e)
        {midlet.note(e.toString());}
        }
    }
