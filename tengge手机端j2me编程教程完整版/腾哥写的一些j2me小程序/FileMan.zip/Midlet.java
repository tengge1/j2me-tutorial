import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Midlet extends MIDlet
{
    //请设置全局变量
    Display display;
    FileMan fc;
    MyPlayer player;
    MyTextBox box;
    MyImage image;
    
    public Midlet()
    {
        //请填充构造方法
        display=Display.getDisplay(this);
        FileMan.midlet=this;
        MyTextBox.midlet=this;
        MyPlayer.midlet=this;
        MyImage.midlet=this;
        fc=new FileMan();
        }
    
    public void startApp()
    {
        display.setCurrent(fc);
        }
    
    public void cmd(String action)
    {
        if(action.equals("退出"))
        notifyDestroyed();
        else if(action.equals("浏览器"))
        {
            display.setCurrent(fc);
            player=null;
            box=null;
            image=null;
            }
        else if(action.endsWith(".mp3")||action.endsWith(".avi")||action.endsWith(".wmv")||action.endsWith(".mid"))
        {
            player=new MyPlayer(action);
            display.setCurrent(player);
            }
        else if(action.endsWith(".txt")||action.endsWith(".java"))
        {
            box=new MyTextBox(action);
            display.setCurrent(box);
            }
        else if(action.endsWith(".jpg")||action.endsWith(".png")||action.endsWith(".gif"))
        {
            image=new MyImage(action);
            display.setCurrent(image);
            }
        }
        
    //信息提示方法
    public void note(String s)
    {
        Alert alert=new Alert("提示",s,null,AlertType.INFO);
        display.setCurrent(alert);
        }
    
    public void pauseApp()
    {
        //请填充暂停程序方法
        try
        {player.stop();}
        catch(Exception e){}
        }
    
    public void destroyApp(boolean unconditional)
    {
        //请填充销毁程序方法
        }
}
