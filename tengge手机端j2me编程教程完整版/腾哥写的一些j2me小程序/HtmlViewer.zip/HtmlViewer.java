import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.io.*;

public class Midlet extends MIDlet implements CommandListener
{
    Display display;
    TextBox textbox;
    Command view,about,back,exit;
    Alert alert;
    
    public Midlet()
    {
        display=Display.getDisplay(this);
        textbox=new TextBox("请输入网址","http://",300,TextField.ANY);
        alert=new Alert("作者","李腾",null,AlertType.INFO);
        alert.setTimeout(5000);
        view=new Command("查看",Command.OK,2);
        about=new Command("关于",Command.OK,2);
        back=new Command("返回",Command.BACK,2);
        exit=new Command("退出",Command.EXIT,2);
        textbox.addCommand(view);
        textbox.addCommand(about);
        textbox.addCommand(exit);
        textbox.setCommandListener(this);
        }
        
    public void startApp()
    {
        display.setCurrent(textbox);
        }
    
    public void commandAction(Command c,Displayable d)
    {
        if(c==view) view();
        if(c==about) about();
        if(c==back) back();
        if(c==exit) notifyDestroyed();
        }
        
    public void view()
    {
        textbox.setTitle("请稍后…");
        textbox.removeCommand(view);
        textbox.removeCommand(about);
        textbox.removeCommand(exit);
        textbox.addCommand(back);
        try
        {
            String string=textbox.getString();
            HttpConnection connection=(HttpConnection)Connector.open(string);
            int length=(int)connection.getLength();
            DataInputStream is=connection.openDataInputStream();
            byte []bytes=new byte[length];
            is.readFully(bytes);
            is.close();
            connection.close();
            String html=new String(bytes,"utf-8");
            textbox.setMaxSize(length);
            textbox.setString(html);
            }
        catch(Exception e)
        {
            note(e.toString());
            }
        textbox.setTitle("网页源码");
        }
    
    public void back()
    {
        textbox.setTitle("请输入网址");
        textbox.removeCommand(back);
        textbox.addCommand(view);
        textbox.addCommand(about);
        textbox.addCommand(exit);
        textbox.setString("http://");
        textbox.setMaxSize(300);
        }
    
    public void about()
    {
        display.setCurrent(alert);
        }
    
    public void note(String string)
    {
        Alert alert=new Alert("提示",string,null,AlertType.INFO);
        alert.setTimeout(500);
        display.setCurrent(alert);
        }

    public void pauseApp() {}
    
    public void destroyApp(boolean arg0) {}
    }
