import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Midlet extends MIDlet implements CommandListener
{
    Display display;
    Form form;
    Command view,about,exit;
    Runtime runtime;
    Alert alert;
    
    public Midlet()
    {
        display=Display.getDisplay(this);
        runtime=Runtime.getRuntime();
        form=new Form("手机信息");
        alert=new Alert("作者","李腾",null,AlertType.INFO);
        alert.setTimeout(5000);
        view=new Command("查看",Command.ITEM,2);
        about=new Command("关于",Command.ITEM,2);
        exit=new Command("退出",Command.EXIT,2);
        form.addCommand(view);
        form.addCommand(about);
        form.addCommand(exit);
        form.setCommandListener(this);
        }
        
    public void startApp()
    {
        display.setCurrent(form);
        }
    
    public void commandAction(Command c,Displayable d)
    {
        if(c==view) view();
        if(c==about) about();
        if(c==exit) notifyDestroyed();
        }
        
    public void view()
    {
        form.deleteAll();
        form.append("手机平台："+System.getProperty("microedition.platform"));
        form.append("\n信息中心："+System.getProperty("wireless.messaging.sms.smsc"));
        form.append("\n总内存："+runtime.totalMemory());
        form.append("\n可用内存："+runtime.freeMemory());
        form.append("\nCLDC版本："+System.getProperty("microedition.configuration"));
        form.append("\nMIDP版本："+System.getProperty("microedition.profiles"));
        form.append("\n默认编码："+System.getProperty("microedition.encoding"));
        form.append("\n所属地区："+System.getProperty("microedition.locale"));
        form.append("\n各种接口版本");
        form.append("\n手机媒体接口："+System.getProperty("microedition.media.version"));
        form.append("\n个人信息管理接口："+System.getProperty("microedition.pim.version"));
        form.append("\n文件系统接口："+System.getProperty("microedition.io.file.FileConnection.version"));
        form.append("\n信令控制接口："+System.getProperty("microedition.sip.version"));
        form.append("\n3D图像处理接口："+System.getProperty("microedition.m3g.version"));
        }
    
    public void about()
    {
        display.setCurrent(alert);
        }
    
    public void pauseApp() {}
    
    public void destroyApp(boolean arg0) {}
    }