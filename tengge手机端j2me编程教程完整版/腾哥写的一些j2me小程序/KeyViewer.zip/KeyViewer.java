import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;


public class Midlet extends MIDlet{
    public void startApp()
    {
        Display dis=Display.getDisplay(this);
        Canvas canvas=new KeyCanvas();
        dis.setCurrent(canvas);
        canvas.setFullScreenMode(true);
        }
    
    public void pauseApp(){}
    
    public void destroyApp(boolean unconditional){}
}


public class KeyCanvas extends GameCanvas
{
     int key=-5;
    
    public KeyCanvas()
    {
        super(false);
        }
    
    protected void paint(Graphics g)
    {
        g.setColor(0,0,255);
        g.fillRect(0,0,getWidth(),getHeight());
        g.setColor(255,255,0);
        g.drawString("按键显示键值，红键退出！",0,30,Graphics.LEFT|Graphics.BASELINE);
        g.drawString("键名："+getKeyName(key),0,60,Graphics.LEFT|Graphics.BASELINE);
        g.drawString("键值："+key,0,90,Graphics.LEFT|Graphics.BASELINE);
        g.drawString("游戏键值："+getGameAction(key),0,120,Graphics.LEFT|Graphics.BASELINE);
        g.drawString("按键状态："+getKeyStates(),0,150,Graphics.LEFT|Graphics.BASELINE);
        g.drawString("作者：李腾",0,getHeight(),Graphics.LEFT|Graphics.BOTTOM);
        }
    
    protected void keyPressed(int keyCode)
    {
        key=keyCode;
        repaint();
        }
    
    protected void keyReleased(int key)
    {
        }
    
    protected void keyRepeated(int key)
    {
        }
     
    }

